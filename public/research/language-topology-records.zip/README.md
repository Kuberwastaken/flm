# FLM language topology: complete score records

These records contain all ten selected models' article scores, the six paired
wiring contrasts, two retrained slow-state contrasts, protocols, frozen identity
records, figure data, and relevant numerical source. All eight new controls
finished before their ten checkpoint selections were frozen and test scored.

To recompute the published arithmetic from this extracted folder:

```sh
python -m pip install -r requirements-audit.txt
python scripts/audit_language_topology_report.py public/research/language-topology-results.json
```

Only Python and NumPy are needed for that command. The checker recomputes exact
byte-weighted losses, per-graph and per-training-seed means, and all eight paired
article-bootstrap intervals (10,000 draws, seed 31415). Negative measured-minus-
control differences favor the measured fast/slow model. Six topology contrasts
share two measured references. Article intervals do not include graph, training
initialization or dataset uncertainty; this is an exploratory extension after
the original measured test results were seen.

This is an arithmetic audit of supplied scores. It is not independent retraining,
test inference, or external authentication of the corpus/checkpoints. The archive
does not contain training data, optimizer state, or model weights. Preserved
training/scoring source is included for inspection, not as a complete training
environment. The corpus card and protocols document what was scored. File hashes
in manifest.json detect changes relative to this supplied record.

The exact four graph inputs are separately downloadable from
https://flm.kuber.studio/research/language-topology-graphs.zip.
The original six-model FLM/GRU/transformer inference release is at
https://flm.kuber.studio/research/wikitext2-inference.zip; that release excludes
these new topology and slow-state checkpoints. Neither the body demonstrations
nor the earlier sensory studies answer the language-topology question.
