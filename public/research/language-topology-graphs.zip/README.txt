FLM language topology: the four exact training graphs, before learned gains.
NPZ arrays are readable with numpy.load(path, allow_pickle=False).
Rows receive signals; columns send signals. Node indices are zero based.
Only the measured graph records retained anatomical edges. Null contacts
and weights are transferred incoming magnitudes, not measured new synapses.
Node CSV includes all 4096 graph/node records. Outgoing weighted strength
is intentionally not fixed. This bundle contains no corpus or model losses.
The identity record binds the original experiment, including local cache
hashes. Full training reproduction requires those separately acquired data.
In the FLM source checkout, run python -m flm.language_structure to audit.
Graph data: CC BY 4.0; source attribution and license included. Code: MIT.
