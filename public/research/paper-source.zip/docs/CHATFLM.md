# ChatFLM: language through fly-derived wiring

FLM is trained from scratch on top of a connectome-derived recurrent core. **No pretrained or overfitted transformer supplies FLM's answers or its displayed neural activity.** Learned text embeddings drive the selected fly graph; its fast and slow state produces next-token probabilities through a learned readout. The primary FLM uses a 1,024-neuron subset; KC previews use their own 487- or 540-neuron subsets. None is an intact fly brain. “From scratch” describes the training origin, not general foundation-model capability.

The useful feature is inspectability: compare predictions, replay an input with a neuron silenced, inspect fast versus slow state, and measure a separate local readout update. [Mechanism controls](LANGUAGE-CORE-RESULTS.md), [training-induced dynamics](LANGUAGE-DYNAMICS-FINDINGS.md) and [physical reference experiments](FOOD-CORE-PHYSICAL-RESULTS.md) answer different questions. The visible typing motion is a designed illustration using the existing articulated body geometry.

## Watching generation

The brain receives actual fast/slow state after every generated token. With **Slow playback for observation** enabled, generation pauses for 60 ms between tokens so the changes can be seen; inference and rendering add time. Disabling it keeps per-token updates and removes the deliberate delay, although the browser may combine paints at high speed. Neuron positions stay fixed, gray context cells are not simulated, and no activity is invented between model steps.

## Models and the automatic default

The selector contains all **18 completed primary neural checkpoints**: FLM, GRU and transformer, each with seeds 42/43, on WikiText-2 and BabyLM 10M/100M. The earlier AMI model and [four KC research previews](SELECTION-PREVIEWS.md) are also available. The previews cover both candidate sides and seeds, have completed validation selection, and remain labeled pending full held-out evaluation. They are excluded from the primary automatic-default ranking. The separately trained GRU and transformer are comparison architectures; selecting them does not create anatomical neuron activity. The topology and computation-control models remain available in their separately documented inference bundles.

Opening ChatFLM without a model query selects **BabyLM 100M FLM, seed 43**, the lowest fixed-panel validation BPB among the four completed BabyLM FLM fits (**1.931862680356**). These candidates share validation text and tokenizer. Test loss and attractive continuations are not selection criteria; WikiText losses are not mixed into this ranking. This selects the strongest measured FLM candidate on that panel, not the strongest architecture overall. Explicit model links are respected, including the older `?model=babylm` and `?model=wikitext` releases.

The [catalog](../public/models/catalog.json) records checkpoint manifest hashes and selection-source hashes. Each package has its own weights, tokenizer and Python parity fixture. The browser verifies manifest, weight and tokenizer hashes before inference. [Catalog tests](../tests/catalog.test.js) compare all 4,096 logits at prefix lengths 1, 12, 97 and 130 for every model, crossing the transformer's 96-position window; FLM's fast/slow state is checked too. These are numerical correctness checks, not a performance benchmark.

## Repetition protection in chat

**Stop repetitive chat output** is on by default and can be switched off in Chat settings. It detects long repeated characters, short repeated patterns, near-uniform letter runs and low-variety digit runs. When triggered, it ends that generation, keeps the prefix before the detected loop, and displays a separate stopping notice. The full sampled output remains in the reply's exported `rawText`, together with `stopReason` and the guard setting. This is a bounded heuristic; intentional repetition can trigger it.

With protection on, replies that stopped for repetition, and older saved replies containing a detected loop, are excluded when constructing follow-up input. User turns and other assistant replies remain eligible under the normal byte limit. The visible conversation is preserved. An input notice, the exact input preview, and each reply's exported `excludedRepetitiveReplies` count disclose the filtering. Switching protection off restores ordinary history inclusion and uncapped-by-repetition sampling. Free-text completion and the published benchmark samples are unchanged.

This prevents a degenerate answer from repeatedly priming the next turn; it does not teach conversational roles or improve the checkpoint's measured language capability. The recurrent state is reset and the declared input replayed for every reply. Displayed neural activity still comes from the actual, possibly stopped, token sequence.

## Conversations and system context

Chat mode stores user/assistant turns and an optional system prompt. **The checkpoints are base next-token models without instruction tuning.** The interface supplies a real conversation history; it does not add a hidden assistant or guarantee that the model follows roles, facts or requests.

The exact input uses ordinary text:

```text
System: optional context

User: first message
Assistant: previous generated reply
User: latest message
Assistant:
```

Open **Chat settings → Inspect the model's input** to inspect the pending input. Exported conversations also retain each reply's exact input, checkpoint hash and sampling settings. The 16,000-byte input limit drops oldest complete turns when needed, preserves system context and the latest user turn, and reports how many older messages were omitted. This is an input-size bound, not a guarantee of memory retention: FLM compresses history into recurrent state, while the transformer uses a finite attention cache.

Generation stops at EOS, the token cap, Stop, or a new line beginning `User:`, `Assistant:` or `System:`. Role stopping is display logic and can also truncate a quoted role label. The complete decoded sampled suffix is retained as `rawText` in the export; displayed text and raw text can differ. Nothing is rewritten into a better answer. Token/byte counts describe sampled output, including any stopped marker. **Continue text** preserves literal continuation behavior; **Legacy dialogue** retains the earlier AMI speaker format.

Enter sends; Shift+Enter inserts a line. History, system context and exported learning stay scoped to the selected checkpoint. Browser storage may be unavailable or full; exports remain available. Local adaptation updates a separate readout adapter, not the released recurrent weights. Switching models reloads the workspace, so save or export local learning before switching.

## Workspace and scope

Desktop has conversation on the left, actual FLM state at upper right and the 3D typing fly below it. Neuron controls, predictions and the original state-to-pose body comparison are under disclosures. Small screens stack these views. Light/dark mode follows the system until manually selected, then persists locally. Reduced-motion preferences suppress typing movement.

The layout draws on common conversation, composer and model-selection patterns documented in [AI Elements](https://elements.ai-sdk.dev/examples/chatbot). The implementation uses native HTML controls and the existing local worker; it does not import that template's framework or hosted model service.

See the [completed BabyLM findings](BABYLM-FINDINGS.md) for comparative losses and output limitations, and the [registered selection study](SELECTION-LANGUAGE-PROTOCOL.md) for the continuing test of which circuits to retain. A chat interface is not evidence of reliable chatbot performance.
