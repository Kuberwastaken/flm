FLM untrained graph preparation archive

Contains 64 anatomical selection graphs and parameter/interface checks.
No language weights or tokenizer are included. No graph is certified intact.
Load an NPZ using numpy.load(path, allow_pickle=False); row is postsynaptic,
col is presynaptic, source_indices map to the acquired source, and body_ids
preserve source identities. See manifest.json for every graph checksum,
selection identity, model configuration, assumptions and limitations.
Graphs derive from MaleCNS, https://male-cns.janelia.org/download/, CC BY 4.0.
License: https://creativecommons.org/licenses/by/4.0/
The acquired runtime derivative comes from Xenova/fruit-fly-simulation; its
pinned Hugging Face source URL and revision are preserved in manifest.json.
FLM original code: Kuber Mehta, MIT.
