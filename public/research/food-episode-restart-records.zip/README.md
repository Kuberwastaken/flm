# Physical food episode restart records

Kuber Mehta. Four fixed cores: direct 20-ms run, interrupted 10-ms attempt, fresh 20-ms restart. All durations exclude factory warmup. Learning disabled; no navigation or adaptation claim.

Every store identity, attempt start, interruption marker and terminal result is retained. A writer.lock file does not mean a process is running. Interrupted physical samples are not checkpointed; the deliberate interruption boundary was observed by the verification harness. Complete result.json.gz records include actual body observations, sensor channels and neural/controller states. The known cached head-row alias and different qpos/body-cache integration stages still apply.

Extract this archive and use scripts/package_food_episode_store.py with the matching research sources, recorded NumPy version and separate food-core-interface.zip to verify all terminal controller/geometry records without running physics. See https://flm.kuber.studio/research/food-episode-runner.md and https://flm.kuber.studio/research/paper-source.zip. For that audit, point --input at the extracted records/ folder.
