# FLM recurrent dynamics replay

This archive reproduces the seven synthetic-pulse conditions in the findings.
It contains the four recurrent parameter groups, the graph subset, the original
numerical sources, complete results and attribution. It does not contain lexical
language weights, training checkpoints, optimizer state or a corpus.

Use a fresh Python environment (the recorded run used Python 3.10.11):

    python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cpu
    python -m pip install numpy==2.2.6 scipy==1.13.1 tokenizers==0.22.2
    python -E scripts/replay_language_dynamics.py --output fresh-replay.json

The command reconstitutes each recurrent core, validates the acute swaps, and
recomputes all metrics and saved arrays. Exact reproduction is checked against
the recorded one-thread CPU environment; other platforms may differ numerically.
No training repository or original checkpoints are accessed. A freshly initialized
lexical interface exists in memory but is bypassed by the direct-drive diagnostic.
For text generation use the separate topology inference release on the website.

Read docs/LANGUAGE-DYNAMICS-FINDINGS.md and the frozen protocol first. Curves are
model updates, not biological time or a measure of useful memory. These results
do not establish anatomical advantage, better language prediction or behavior
transfer. Historical full-checkpoint hashes document provenance; the archive
does not independently establish the training history of those checkpoints.

manifest.json checks file consistency, not publisher authenticity. The script
language_dynamics_study.py is the historical repository harness; use the replay
wrapper above because the historical harness expects the full local run files.

Source code: MIT, Kuber Mehta. Graph data: MaleCNS, CC BY 4.0; see licenses/.
