# Short physical food-episode integration records

Kuber Mehta. Eight 20-ms post-warmup rollouts; four fixed exported cores, each repeated. Learning was disabled. These records demonstrate connection and repeatability, not navigation, food-task learning or language benefit.

Each NPZ contains three observations and only two applied descending commands. The final action/uniform values of -1 mean no action/draw; the final zero drive is not applied. Controller JSON records the exact sensory/action history and frozen identities. The existing body-state limitation remains: the invalid c_head row aliases a hind foot. Use the recorded valid sensor origins; qpos and cached body positions describe different integration stages.

The manifest checks bytes only. Source and reproduction instructions: https://flm.kuber.studio/research/food-episode-runner.md and https://flm.kuber.studio/research/paper-source.zip. The separate four-core interface package is required for numerical replay or physical reruns. Controller replay does not replay physics or restore a simulator/gait checkpoint.
