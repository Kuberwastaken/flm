# FLM: run the language computation controls

FLM by Kuber Mehta. This archive contains eight selected text-continuation
models on the same 1,024-neuron measured graph subset, at training seeds 42 and
43. Six controls were retrained; the two full-model references are reused.
The complete-study gate precedes export. These models are not instruction tuned.
Generated continuations are unedited model output, not factual answers.

Use a Python environment in this extracted directory:

```sh
python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements-inference.txt
python -X utf8 -m flm.core_inference --condition full-s42 --prompt "The history of science"
python -X utf8 -m flm.core_inference --condition fixed_dynamics-s42 --prompt "The history of science"
python -X utf8 -m flm.core_inference --condition no_lateral-s42 --prompt "The history of science"
python -X utf8 -m flm.core_inference --condition no_temporal_state-s42 --prompt "The history of science"
```

Replace s42 with s43 for the other training initialization. Full keeps the
original model class. Fixed dynamics freezes the recurrent edges, gain, and
fast/slow decay parameters at initialization; the lexical interface still
learns through backpropagation through time. No lateral removes communication
between units while retaining their fast and slow temporal states. No temporal
state resets both states on EVERY token, including tokens in a longer prompt.
Stored parameters disconnected from the loss are not effective model capacity.
These mechanisms are checked on load, including exact frozen initial tensors.

Keep prompts and sampling settings equal. Defaults: sampling seed 17,
temperature 0.8, top-k 40, at most 128 output tokens, one CPU thread.
--temperature 0 uses argmax; --tokens accepts 1 to 1024. Generation masks the
beginning-of-document token and control-byte pieces other than tab/newline;
the likelihood evaluation does not apply this generation-only mask.

The exporter compares all tensors and graph/pooling buffers, a fixed-prefix
logit/state probe, and all 32 fixed-prompt continuations against the selected
source checkpoints. The release record separately states whether all eight
first-prompt examples passed fresh-archive CLI replay outside the repository.
Library versions or platforms can change numerical and stochastic output.
Hashes describe this supplied release; they do not independently authenticate
the original research. This verification does not rerun held-out likelihoods.

This is an inference release, not a training-resume archive. No optimizer,
training RNG, raw corpus or user conversation is included. Code and weights use
MIT; the imported graph retains CC BY 4.0 attribution. Corpus provenance is in
data/cards/wikitext2.json. Selection, results and protocols are in reports/ and
docs/. The graph is a computational subset, not an intact fly brain.

These are exploratory mechanism comparisons with two reused full references
and shared test articles, not independent new replications of those references.
Conditional article-bootstrap intervals do not establish general equivalence.
A benefit from recurrence would not establish a benefit from anatomical wiring;
the separate topology study addresses that question. The original comparison
archive includes GRU and transformer baselines.
