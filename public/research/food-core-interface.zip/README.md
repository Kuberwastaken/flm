# FLM frozen sensory interfaces

Four paired initial/language-trained cores, zero food-adaptation updates.
Open-loop numerical replay only; no food skill or transfer result.

With NumPy installed, run from this extracted directory:

```console
python verify_food_core.py . --output fresh-parity.json
```

Use a new output filename. Set OMP_NUM_THREADS, OPENBLAS_NUM_THREADS and
MKL_NUM_THREADS to 1 before launch. Repeated compressed-reference loading
can take several minutes. No training corpus, PyTorch or FlyGym is needed.

manifest.json binds model exports and fixtures; archive-manifest.json
hashes every other member. sources/ preserves the native numerical code;
it is not a full runnable training repository. See the project appendix:
https://flm.kuber.studio/research/food-core-interface.md

Code is MIT licensed. Graph and body provenance and component licenses
are included; preserve their attribution when reusing the material.
