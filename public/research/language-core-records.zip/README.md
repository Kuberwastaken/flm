# FLM language computation: complete score records

FLM by Kuber Mehta. These records contain all eight selected conditions:
full, fixed dynamics, no lateral recurrence and no temporal state, each with
training seeds 42 and 43. The two full-model references reuse the original
WikiText scores; the other six conditions were retrained. The complete-study
gate must pass before this archive is built. No partial score release is made.

To audit the supplied arithmetic from this extracted directory:

```sh
python -m pip install -r requirements-audit.txt
python scripts/audit_language_core_report.py reports/language-core/summary.json
```

Only Python and NumPy are needed for that command. The independent checker
recomputes article and aggregate losses, byte-weighted BPB, shared-tokenizer
perplexity, all six primary and two secondary paired-article intervals, and
their declared descriptive means. The release is also checked from a fresh
archive extraction outside the repository with FLM and PyTorch imports disabled.
Numeric comparisons allow relative 1e-9 / absolute 1e-12 rounding tolerance.

All eight conditions, 480 article-score rows, and eight contrast rows are also
provided as CSVs under tables/. No article text or tokenized corpus is included.
The graph card and protocols describe the measured 1,024-neuron subset and its
limits. This is not an intact fly brain. Freezing recurrent dynamics leaves
the lexical interface trainable through time. No lateral recurrence retains
fast and slow temporal memory; no temporal state resets both on every token.
Allocated, trainable and frozen parameter counts must not be conflated with
effective capacity. See the protocol for disconnected trainable parameters.

Primary effects are full minus each control; negative favors full. The
secondary effect is no-lateral minus no-temporal-state. All eight intervals
use 10,000 paired-article draws with seed 31415. They condition on fitted models;
shared references/articles and two initializations do not establish training
uncertainty. No confidence interval for a descriptive mean is declared. This
exploratory follow-up does not test equivalence or topology-by-trainability.
It cannot reverse the separate topology study's no-anatomical-advantage result.

This is an arithmetic audit of supplied scores, not independent retraining,
held-out inference or authentication of data/checkpoints. Manifest hashes
describe this supplied record. Numerical sources are included for inspection,
not as a complete training environment. No model weights, optimizer states,
training RNG, raw corpus or user conversations are included. Source cards and
protocols preserve data and graph attribution; code uses MIT.

The selected models are released separately in language-core-inference.zip.
The earlier wikitext2-inference.zip includes GRU and transformer baselines;
language-topology-records.zip contains the separate anatomical wiring controls.
These archives are served under https://flm.kuber.studio/research/.
