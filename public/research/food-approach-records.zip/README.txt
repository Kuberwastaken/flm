Scripted physical food-approach reference v1

Install NumPy, then audit the extracted complete directory:
python audit_food_approach.py . --output fresh-audit.json

The audit replays supplied geometry and actions, not physics or learning.
Read docs/FOOD-APPROACH-REFERENCE.md for the prior declaration and scope.
The physical runner requires the pinned isolated FlyGym environment.
